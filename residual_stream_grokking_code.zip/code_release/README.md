# Residual-Stream Component in Grokking

Code accompanying the paper:

**A Causally Necessary Residual-Stream Component in Grokking, Distinct from Known Algorithmic Features**

## Requirements

```bash
pip install torch transformer-lens einops numpy matplotlib seaborn
```

Recommended: CUDA GPU (tested on RTX 4090).

## Scripts

| Script | Purpose |
|--------|---------|
| `scripts/run_discovery_check.py` | Full pipeline for modular **addition** (train → extract → causal ablation) |
| `scripts/run_discovery_multiplication.py` | Same pipeline for modular **multiplication** |
| `scripts/layer_sweep.py` | Causal effect + overlap at every layer |
| `scripts/positive_control_fourier.py` | Validates that the pipeline recovers known Fourier features |
| `scripts/plot_paper_figures.py` | Reproduces Figures 1–5 |

## Quick Start

```bash
# Addition, d_model=256, a few seeds
CUDA_VISIBLE_DEVICES=0 python scripts/run_discovery_check.py --d_model 256 --start 12000 --end 12004

# Multiplication
CUDA_VISIBLE_DEVICES=0 python scripts/run_discovery_multiplication.py --d_model 256 --start 20000 --end 20003

# Layer sweep (requires a saved checkpoint)
python scripts/layer_sweep.py --checkpoint results_discovery/grokked_d256_seed12000.pt --d_model 256 --seed 12000

# Positive control
python scripts/positive_control_fourier.py --checkpoint results_discovery/grokked_d256_seed12000.pt --d_model 256 --seed 12000

# Figures
python scripts/plot_paper_figures.py
```

## Design Notes

- **Contrastive extraction**: train-mean residual − held-out-mean residual, then low-rank SVD (k=16).
- **Causal test**: phase-cancellation ablation at coefficients 0 / 1 / 2.
- **Controls**: matched random subspaces + task-specific algorithmic features.
- Primary results reported at the final residual stream (Layer 1).

## Citation

If you use this code, please cite the accompanying paper.
